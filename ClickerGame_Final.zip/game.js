let score = parseInt(localStorage.getItem("score")) || 0;
let best = parseInt(localStorage.getItem("best")) || 0;
let pointsPerClick = parseInt(localStorage.getItem("pointsPerClick")) || 1;
let autoClickers = parseInt(localStorage.getItem("autoClickers")) || 0;

const scoreDisplay = document.getElementById('score');
const bestDisplay = document.getElementById('best');
const clickBtn = document.getElementById('clickBtn');
const upgradeClick = document.getElementById('upgradeClick');
const buyAuto = document.getElementById('buyAuto');
const resetGame = document.getElementById('resetGame');

function update() {
  scoreDisplay.textContent = score;
  bestDisplay.textContent = best;
  localStorage.setItem("score", score);
  localStorage.setItem("best", best);
  localStorage.setItem("pointsPerClick", pointsPerClick);
  localStorage.setItem("autoClickers", autoClickers);
}

function showAd() {
  alert("Реклама: Получи бонус за продолжение игры!");
  // Здесь нужно будет подключить рекламный SDK Яндекс Игр
}

clickBtn.onclick = () => {
  score += pointsPerClick;
  if (score > best) best = score;
  if (score % 100 === 0) showAd();
  update();
};

upgradeClick.onclick = () => {
  if (score >= 10) {
    score -= 10;
    pointsPerClick++;
    update();
  }
};

buyAuto.onclick = () => {
  if (score >= 50) {
    score -= 50;
    autoClickers++;
    update();
  }
};

resetGame.onclick = () => {
  if (confirm("Точно сбросить игру?")) {
    score = 0; pointsPerClick = 1; autoClickers = 0; best = 0;
    update();
  }
};

setInterval(() => {
  if (autoClickers > 0) {
    score += autoClickers;
    if (score > best) best = score;
    update();
  }
}, 1000);

update();